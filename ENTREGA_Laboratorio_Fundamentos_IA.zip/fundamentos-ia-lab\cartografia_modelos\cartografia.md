# Cartografía del ecosistema de modelos de IA (Componente 1)

**Equipo:** Juan Diego Gómez Betancur · Nicolás Giraldo Tobón · Mateo Agudelo Castro
**Fecha de consulta:** 22/09/2026

La matriz completa, con 20 modelos y la fuente de cada uno, está en [`modelos.csv`](modelos.csv), que se abre en Excel.
Categorías cubiertas: texto/generalistas, razonamiento, desarrollo de software, visión/multimodal, voz (STT y TTS) y embeddings.

> **Nota de verificación:** en los modelos cloud, el proveedor no publica el tamaño y los precios
> cambian a menudo. Por eso la matriz enlaza la página oficial de modelos/precios en lugar de copiar
> una cifra que puede quedar desactualizada. Los tamaños de los modelos locales corresponden a la
> cuantización Q4 que ofrece la librería de Ollama.

## Resumen por categoría

| Categoría | Opción local (privada, gratis) | Opción cloud (más capaz, de pago) |
|---|---|---|
| Texto / generalista | Llama 3.2 3B, Gemma 3 4B, Qwen3 | GPT-5.5, Claude, Gemini 3.x |
| Razonamiento | DeepSeek-R1 7B, Qwen3 (modo thinking) | Claude Opus 5.5, Gemini 3.x Pro |
| Código | Qwen2.5-Coder 3B/7B, Codestral | GPT-5.x-Codex, Claude Code |
| Visión | Qwen2.5-VL 3B/7B, Gemma 3 4B, Llama 3.2 Vision | GPT-5.5, Gemini 3.x |
| Voz STT | Whisper (small / turbo) | API de transcripción de OpenAI |
| Voz TTS | Piper, Kokoro-82M | TTS de OpenAI / Google |
| Embeddings | nomic-embed-text, bge-m3, Qwen3-Embedding | text-embedding-3-small/large |

## Pregunta central: ¿qué modelo usaríamos para cada problema y por qué?

No existe un "mejor modelo" universal. La elección depende de cinco variables:
**tarea, recursos, privacidad, costo y modalidad.**

| Problema | Elección | Justificación |
|---|---|---|
| Chat general en **nuestro PC** (16 GB RAM, sin GPU) | **Llama 3.2 3B** (Ollama) | Pesa ~2 GB en Q4, corre fluido en CPU y deja RAM libre. Un 7B también cabe, pero responde de 2 a 3 veces más lento. |
| Generar o explicar código **sin enviarlo a terceros** (p. ej. código de una empresa) | **Qwen2.5-Coder 3B/7B** local | Especializado en código y con privacidad total, a costo cero. A cambio, comete más errores que un modelo cloud. |
| Desarrollar una app completa rápido (vibe coding) | **Claude / Codex** (cloud) | Mucho más precisos y capaces de ejecutar y corregir su propio código. Cuestan dinero y requieren enviar el código a la nube. |
| Problema de lógica o matemáticas paso a paso | **DeepSeek-R1** local, o Claude Opus / Gemini Pro en cloud | Los modelos de razonamiento "piensan" antes de responder. En CPU local son lentos porque generan muchos tokens. |
| Leer una factura o captura de pantalla | **Qwen2.5-VL 3B** local | Hace falta modalidad visual (VLM), no basta un LLM de texto. El de 3B es el que cabe en nuestro hardware. |
| Transcribir la grabación de una clase | **Whisper small / turbo** local | STT especializado, gratis y open-weight. Con la versión small, la CPU basta. |
| Asistente que responda en voz alta sin internet | **Piper** o **Kokoro-82M** | TTS muy liviano y 100 % local. |
| Buscador semántico / RAG sobre apuntes del curso | **bge-m3** o **nomic-embed-text** | Un embedding convierte texto en vectores. No genera texto, pero es la base de la búsqueda semántica. bge-m3 maneja bien el español. |
| Documento muy largo (cientos de páginas) | **Gemini 3.x** (cloud) | Necesita una ventana de contexto muy grande que ningún modelo local de nuestro tamaño ofrece. |

**Conclusión.** Para aprender, para datos privados y para tareas acotadas, los modelos locales pequeños
(3–4B en Q4) son suficientes y gratuitos en nuestro hardware. Cuando la tarea exige más calidad,
contexto largo o autonomía de agente, compensa pagar un modelo cloud, sabiendo que los datos
salen del equipo. En nuestro PC (16 GB RAM y gráficos integrados), el límite práctico está en
modelos de hasta unos 7–8B en Q4. Por encima de eso, la inferencia en CPU se vuelve demasiado lenta.
