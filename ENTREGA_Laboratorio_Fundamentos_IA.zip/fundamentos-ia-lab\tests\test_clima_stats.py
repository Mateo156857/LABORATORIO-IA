"""Pruebas de la solución cloud de Vibe Coding (función validate)."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "vibe_coding" / "solucion_cloud"))
from clima_stats import compute_stats, validate  # noqa: E402


def test_validate_ok_ignora_nulos():
    data = {"hourly": {"time": ["2026-09-22T00:00", "2026-09-22T01:00", "2026-09-22T02:00"],
                       "temperature_2m": [12.0, None, 14.0]}}
    df = validate(data)
    assert len(df) == 2
    assert compute_stats(df)["media"] == 13.0


def test_validate_tamanos_distintos():
    with pytest.raises(ValueError):
        validate({"hourly": {"time": ["2026-09-22T00:00"], "temperature_2m": [1, 2]}})


def test_validate_sin_hourly():
    with pytest.raises(ValueError):
        validate({"error": True})
