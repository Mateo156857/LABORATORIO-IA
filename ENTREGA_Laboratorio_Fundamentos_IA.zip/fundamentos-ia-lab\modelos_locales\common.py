"""
common.py - Utilidades compartidas: consultas equivalentes, medición de RAM y registro CSV.

Las MISMAS consultas se envían a Ollama y a LM Studio para poder comparar.
"""
from __future__ import annotations

import csv
import platform
from datetime import datetime
from pathlib import Path

import psutil

# Conjunto equivalente de consultas (actividad 6.1.5)
PROMPTS = [
    ("general", "Explica en máximo 5 líneas qué es una ventana de contexto en un LLM."),
    ("general", "¿Cuál es la diferencia entre entrenamiento e inferencia? Da un ejemplo."),
    ("codigo", "Escribe una función en Python que reciba una lista de números y devuelva la media móvil de ventana 3. Incluye un ejemplo de uso."),
    ("codigo", "Explica qué hace este código y si tiene algún error:\n\ndef div(a, b):\n    return a / b\nprint(div(10, 0))"),
]

EVIDENCE_DIR = Path(__file__).resolve().parents[1] / "evidence"
PROCESS_KEYWORDS = ("ollama", "llama", "lm studio", "lmstudio", "lms")


def ram_snapshot() -> dict:
    """RAM total usada por el sistema y RAM de los procesos del runtime (Ollama / LM Studio)."""
    vm = psutil.virtual_memory()
    runtime_mb = 0.0
    for p in psutil.process_iter(["name", "memory_info"]):
        try:
            name = (p.info["name"] or "").lower()
            if any(k in name for k in PROCESS_KEYWORDS) and p.info["memory_info"]:
                runtime_mb += p.info["memory_info"].rss / 1024**2
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return {
        "ram_sistema_usada_gb": round(vm.used / 1024**3, 2),
        "ram_sistema_total_gb": round(vm.total / 1024**3, 2),
        "ram_procesos_runtime_mb": round(runtime_mb, 1),
    }


def environment_info() -> dict:
    return {
        "so": f"{platform.system()} {platform.release()}",
        "cpu": platform.processor() or platform.machine(),
        "nucleos_logicos": psutil.cpu_count(logical=True),
        "ram_total_gb": round(psutil.virtual_memory().total / 1024**3, 2),
        "python": platform.python_version(),
    }


def append_log(filename: str, row: dict) -> Path:
    """Agrega una fila al registro técnico CSV en /evidence."""
    EVIDENCE_DIR.mkdir(exist_ok=True)
    path = EVIDENCE_DIR / filename
    new = not path.exists()
    row = {"fecha": datetime.now().isoformat(timespec="seconds"), **row}
    with path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(row.keys()))
        if new:
            w.writeheader()
        w.writerow(row)
    return path
