"""
model.py - Baselines y modelo predictivo básico.

Todos los métodos hacen pronóstico "un paso adelante" (día siguiente):
para predecir el día t solo usan valores observados hasta t-1.
Así nunca se usa información futura para predecir el pasado.

  * persistence       : y_hat(t) = y(t-1)                         (baseline 1)
  * moving_average    : y_hat(t) = media(y(t-k) ... y(t-1))       (baseline 2)
  * LagRegression     : regresión lineal con rezagos + estacionalidad anual (modelo predictivo)
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

LAGS = [1, 2, 3, 7, 14]


def persistence_forecast(full: pd.Series, test_index: pd.Index) -> pd.Series:
    """Predice que mañana será igual que hoy."""
    return full.shift(1).loc[test_index].rename("persistencia")


def moving_average_forecast(full: pd.Series, test_index: pd.Index, window: int = 7) -> pd.Series:
    """Media de los últimos `window` días (shift(1) evita incluir el día a predecir)."""
    return full.shift(1).rolling(window).mean().loc[test_index].rename(f"media_movil_{window}")


def make_features(full: pd.Series) -> pd.DataFrame:
    """Rezagos + codificación seno/coseno del día del año (estacionalidad)."""
    X = pd.DataFrame(index=full.index)
    for lag in LAGS:
        X[f"lag_{lag}"] = full.shift(lag)
    X["rolling_mean_7"] = full.shift(1).rolling(7).mean()
    doy = full.index.dayofyear
    X["sin_doy"] = np.sin(2 * np.pi * doy / 365.25)
    X["cos_doy"] = np.cos(2 * np.pi * doy / 365.25)
    return X


class LagRegression:
    """Regresión lineal sobre rezagos. Se entrena SOLO con el periodo de entrenamiento."""

    def __init__(self) -> None:
        self.model = LinearRegression()
        self.feature_names: list[str] = []

    def fit(self, full: pd.Series, train_index: pd.Index) -> "LagRegression":
        X = make_features(full).loc[train_index]
        y = full.loc[train_index]
        mask = X.notna().all(axis=1)  # las primeras filas no tienen rezagos
        self.feature_names = list(X.columns)
        self.model.fit(X[mask], y[mask])
        return self

    def predict(self, full: pd.Series, test_index: pd.Index) -> pd.Series:
        # Las features del día t solo contienen valores de días < t (todas usan shift >= 1)
        X = make_features(full).loc[test_index]
        return pd.Series(self.model.predict(X), index=test_index, name="regresion_rezagos")

    def coefficients(self) -> dict:
        return {n: round(float(c), 4) for n, c in zip(self.feature_names, self.model.coef_)}
