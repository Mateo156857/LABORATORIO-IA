Aquí tienes el código que se ajusta a tus especificaciones:

```python
import requests
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def obtener_datos_clima():
    url = "https://api.open-meteo.com/v1/forecast?latitude=4.61&longitude=-74.08&hourly=temperature_2m&forecast_days=7&timezone=America/Bogota"
    try:
        respuesta = requests.get(url)
        respuesta.raise_for_status()
        datos = respuesta.json()
        return datos
    except requests.exceptions.RequestException as e:
        print(f"Error de red: {e}")
        return None

def validar_respuesta(respuesta):
    if respuesta is None:
        return False
    if respuesta["hourly"]["time"] is None or respuesta["hourly"]["temperature_2m"] is None:
        return False
    if len(respuesta["hourly"]["time"]) != len(respuesta["hourly"]["temperature_2m"]):
        return False
    for temperatura in respuesta["hourly"]["temperature_2m"]:
        if temperatura is None:
            return False
    return True

def calcular_estadisticas(respuesta):
    if respuesta is None:
        return None
    datos = respuesta["hourly"]
    minimo = np.min([temperatura for temperatura in datos["temperature_2m"] if temperatura is not None])
    maximo = np.max([temperatura for temperatura in datos["temperature_2m"] if temperatura is not None])
    media = np.mean([temperatura for temperatura in datos["temperature_2m"] if temperatura is not None])
    desviacion_estandar = np.std([temperatura for temperatura in datos["temperature_2m"] if temperatura is not None])
    temperatura_media = np.mean([temperatura for temperatura in datos["temperature_2m"] if temperatura is not None])
    return {
        "minimo": minimo,
        "maximo": maximo,
        "media": media,
        "desviacion_estandar": desviacion_estandar,
        "temperatura_media": temperatura_media
    }

def graficar_temperatura(respuesta):
    if respuesta is None:
        return None
    datos = respuesta["hourly"]
    temperatura_media = np.mean([temperatura for temperatura in datos["temperature_2m"] if temperatura is not None])
    plt.plot([temperatura for temperatura in datos["time"]], [temperatura for temperatura in datos["temperature_2m"]])
    plt.axhline(y=temperatura_media, color='r', linestyle='--')
    plt.title("Temperatura media por hora")
    plt.xlabel("Hora")
    plt.ylabel("Temperatura (°C)")
    plt.savefig("temperatura.png")
    plt.close()

def main():
    respuesta = obtener_datos_clima()
    if respuesta is not None:
        if validar_respuesta(respuesta):
            estadisticas = calcular_estadisticas(respuesta)
            print("Estadísticas climáticas:")
            print(f"Minimo: {estadisticas['minimo']}")
            print(f"Maximo: {estadisticas['maximo']}")
            print(f"Media: {estadisticas['media']}")
            print(f"Desviacion estandar: {estadisticas['desviacion_estandar']}")
            print(f"Temperatura media: {estadisticas['temperatura_media']}")
            graficar_temperatura(respuesta)
        else:
            print("Respuesta no válida")

if __name__ == "__main__":
    main()
```

Para probar la función de validación, puedes crear un archivo `test_clima_stats.py` con el siguiente contenido:

```python
import pytest
from clima_stats import obtener_datos_clima, validar_respuesta

def test_validar_respuesta():
    respuesta = {
        "hourly": {
            "time": [1, 2, 3],
            "temperature_2m": [20, 21, 22]
        }
    }
    assert validar_respuesta(respuesta) == True

def test_validar_respuesta_falla():
    respuesta = {
        "hourly": {
            "time": [1, 2, 3],
            "temperature_2m": [None, 21, 22]
        }
    }
    assert validar_respuesta(respuesta) == False

def test_validar_respuesta_nulo():
    respuesta = None
    assert validar_respuesta(respuesta) == False
```

Para ejecutar las pruebas, puedes utilizar el comando `pytest test_clima_stats.py`.