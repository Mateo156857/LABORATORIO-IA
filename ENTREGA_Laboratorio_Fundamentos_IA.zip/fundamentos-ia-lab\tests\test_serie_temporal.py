"""Pruebas unitarias del reto integrador. Ejecutar con:  pytest -q"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "serie_temporal"))

from evaluation import mae, rmse  # noqa: E402
from model import LagRegression, moving_average_forecast, persistence_forecast  # noqa: E402
from preprocessing import json_to_dataframe, train_test_split_temporal, validate_and_clean  # noqa: E402


def fake_api_json(n=400, with_problems=False):
    """JSON con la MISMA estructura que devuelve Open-Meteo (solo para pruebas)."""
    dates = pd.date_range("2023-01-01", periods=n, freq="D").strftime("%Y-%m-%d").tolist()
    rng = np.random.default_rng(0)
    temps = (14 + 1.5 * np.sin(np.arange(n) * 2 * np.pi / 365) + rng.normal(0, 0.6, n)).round(1).tolist()
    if with_problems:
        temps[10] = None                      # faltante
        dates[20], dates[21] = dates[21], dates[20]  # desorden
        dates.append(dates[5]); temps.append(99.0)   # duplicado
        del dates[30]; del temps[30]          # hueco de calendario
    return {"latitude": 4.6, "longitude": -74.1, "daily": {"time": dates, "temperature_2m_mean": temps}}


def test_tipos_y_orden():
    df, rep = validate_and_clean(json_to_dataframe(fake_api_json(with_problems=True)))
    assert isinstance(df.index, pd.DatetimeIndex)
    assert df.index.is_monotonic_increasing
    assert not df.index.duplicated().any()
    assert df["temperature_2m_mean"].dtype == float
    assert df["temperature_2m_mean"].isna().sum() == 0
    assert rep["fechas_duplicadas_eliminadas"] == 1
    assert rep["dias_faltantes_en_calendario"] == 1
    assert rep["venia_ordenada"] is False


def test_split_respeta_orden():
    df, _ = validate_and_clean(json_to_dataframe(fake_api_json()))
    train, test = train_test_split_temporal(df["temperature_2m_mean"], 30)
    assert train.index.max() < test.index.min()
    assert len(test) == 30


def test_split_invalido():
    s = pd.Series([1.0, 2.0], index=pd.date_range("2024-01-01", periods=2))
    with pytest.raises(ValueError):
        train_test_split_temporal(s, 5)


def test_metricas():
    y, p = pd.Series([1.0, 2.0, 3.0]), pd.Series([1.0, 2.0, 5.0])
    assert mae(y, p) == pytest.approx(2 / 3)
    assert rmse(y, p) == pytest.approx(np.sqrt(4 / 3))


def test_sin_fuga_de_informacion_futura():
    """Si alteramos el futuro, las predicciones del pasado no deben cambiar."""
    df, _ = validate_and_clean(json_to_dataframe(fake_api_json()))
    s = df["temperature_2m_mean"]
    train, test = train_test_split_temporal(s, 60)
    first_day = test.index[:1]
    s_mod = s.copy()
    s_mod.loc[test.index[1]:] = 999  # "futuro" absurdo
    m1 = LagRegression().fit(s, train.index).predict(s, first_day)
    m2 = LagRegression().fit(s_mod, train.index).predict(s_mod, first_day)
    assert m1.iloc[0] == pytest.approx(m2.iloc[0])
    assert persistence_forecast(s, first_day).iloc[0] == persistence_forecast(s_mod, first_day).iloc[0]
    assert moving_average_forecast(s, first_day).iloc[0] == moving_average_forecast(s_mod, first_day).iloc[0]
