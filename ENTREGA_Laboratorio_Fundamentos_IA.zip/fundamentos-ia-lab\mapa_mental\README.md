# Mapa mental técnico – Fundamentos de modelos de IA (Componente 0)

Archivos: `mapa_mental.png`, `mapa_mental.pdf` y `mapa_mental.dot`, que es la fuente editable con Graphviz.

- **Líneas sólidas:** jerarquía (rama → concepto).
- **Líneas punteadas amarillas:** relaciones entre ramas.

Cada nodo responde brevemente **qué es**, da **un ejemplo** e indica **dónde se usa en el laboratorio**
(C1 = cartografía, C2 = Ollama/LM Studio, C3 = Vibe Coding, C4 = reto de series temporales).

## Relaciones clave que muestra el mapa

1. **ML ⊃ Deep Learning ⊃ redes neuronales → Transformer → modelos fundacionales → LLM.**
   Todos los modelos del laboratorio son Transformers preentrenados.
2. **Parámetros + cuantización → RAM.** Un modelo de 3B en Q4 ocupa ~2 GB. Con 16 GB de RAM y sin
   GPU dedicada, el límite práctico está en ~7–8B. Por eso usamos **SLM** de 3B.
3. **SLM + open-weight → modelo local.** Solo los modelos con pesos descargables se pueden ejecutar
   en nuestro equipo. Los **propietarios** se usan en la nube, vía API.
4. **Ollama / LM Studio → API → aplicación Python.** Es la cadena
   MODELO → RUNTIME → API LOCAL → APLICACIÓN del Componente 2.
5. **Inferencia ≠ entrenamiento.** En el laboratorio solo hacemos inferencia (en CPU). El único
   "entrenamiento" es el de la regresión lineal del C4, que es ML clásico y no deep learning.
6. **Ventana de contexto se mide en tokens.** Limita cuánto código o texto se le puede pasar al
   modelo en el Vibe Coding.
7. **Temperatura** baja (0,2) en los scripts, para obtener respuestas más estables y comparables
   entre Ollama y LM Studio.
