"""
app.py - Aplicación integradora.

Flujo: API -> JSON -> Python/Pandas -> preparación -> serie temporal -> modelo
       -> predicción -> MAE/RMSE -> gráficas

Uso (desde la raíz del repositorio):
    python serie_temporal/app.py                 # últimos 3 años, Bogotá
    python serie_temporal/app.py --years 5 --test-days 60
    python serie_temporal/app.py --offline data.json   # reutiliza un JSON ya descargado
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from api_client import default_date_range, fetch_daily_weather, save_raw  # noqa: E402
from evaluation import metrics_table, plot_errors, plot_predictions, plot_series  # noqa: E402
from model import LagRegression, moving_average_forecast, persistence_forecast  # noqa: E402
from preprocessing import json_to_dataframe, train_test_split_temporal, validate_and_clean  # noqa: E402

TARGET = "temperature_2m_mean"
ROOT = Path(__file__).resolve().parents[1]


def run(years: int, test_days: int, offline: str | None, out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. API -> JSON
    if offline:
        data = json.loads(Path(offline).read_text(encoding="utf-8"))
        print(f"[1] Datos cargados desde archivo local: {offline}")
    else:
        start, end = default_date_range(years)
        print(f"[1] Consultando Open-Meteo ({start} -> {end}) ...")
        data = fetch_daily_weather(start, end)
        raw_path = save_raw(data, out_dir / "respuesta_api_raw.json")
        print(f"    JSON crudo guardado en {raw_path}")
    print(f"    Coordenadas devueltas: lat={data.get('latitude')} lon={data.get('longitude')} tz={data.get('timezone')}")

    # 2. JSON -> DataFrame + validación
    df = json_to_dataframe(data)
    df, report = validate_and_clean(df, TARGET)
    print("[2] Reporte de calidad de datos:")
    for k, v in report.items():
        print(f"    - {k}: {v}")
    df.to_csv(out_dir / "serie_limpia.csv")

    # 3. Serie temporal + división temporal
    series = df[TARGET]
    train, test = train_test_split_temporal(series, test_days)
    print(f"[3] Train: {train.index.min().date()} -> {train.index.max().date()} ({len(train)} días)")
    print(f"    Test : {test.index.min().date()} -> {test.index.max().date()} ({len(test)} días)")

    # 4. Baselines + modelo
    preds = {
        "Persistencia (baseline)": persistence_forecast(series, test.index),
        "Media móvil 7d (baseline)": moving_average_forecast(series, test.index, 7),
    }
    reg = LagRegression().fit(series, train.index)
    preds["Regresión con rezagos"] = reg.predict(series, test.index)
    print("[4] Coeficientes de la regresión:", reg.coefficients())

    # 5. Métricas
    table = metrics_table(test, preds)
    print("[5] Métricas en el periodo de prueba:")
    print(table.to_string(index=False))
    table.to_csv(out_dir / "metricas.csv", index=False)

    # 6. Gráficas
    plot_series(series, test.index.min(), out_dir / "01_serie_temporal.png",
                f"Temperatura media diaria - lat {data.get('latitude')}, lon {data.get('longitude')} (Open-Meteo)")
    plot_predictions(test, preds, out_dir / "02_real_vs_prediccion.png")
    best = table.iloc[0]["modelo"]
    plot_errors(test, preds[best], best, out_dir / "03_errores_mejor_modelo.png")
    print(f"[6] Gráficas guardadas en {out_dir}")

    summary = {
        "fecha_ejecucion": datetime.now().isoformat(timespec="seconds"),
        "fuente": "Open-Meteo Historical Weather API" if not offline else f"archivo {offline}",
        "reporte_calidad": report,
        "metricas": table.to_dict(orient="records"),
        "mejor_modelo": best,
        "coeficientes_regresion": reg.coefficients(),
    }
    (out_dir / "resumen_ejecucion.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    p = argparse.ArgumentParser(description="Serie temporal de temperatura con Open-Meteo")
    p.add_argument("--years", type=int, default=3, help="años de historia a descargar")
    p.add_argument("--test-days", type=int, default=90, help="días finales reservados para prueba")
    p.add_argument("--offline", type=str, default=None, help="ruta a un JSON ya descargado")
    p.add_argument("--out", type=str, default=str(ROOT / "evidence" / "serie_temporal"))
    a = p.parse_args()
    run(a.years, a.test_days, a.offline, Path(a.out))


if __name__ == "__main__":
    main()
