"""
evaluation.py - Métricas y gráficas.

MAE  = promedio de |real - predicho|            -> error típico en °C
RMSE = raíz del promedio de (real - predicho)^2 -> castiga más los errores grandes
"""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # permite guardar gráficas sin ventana (funciona en cualquier PC)
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def mae(y_true: pd.Series, y_pred: pd.Series) -> float:
    return float(np.mean(np.abs(np.asarray(y_true) - np.asarray(y_pred))))


def rmse(y_true: pd.Series, y_pred: pd.Series) -> float:
    return float(np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2)))


def metrics_table(y_true: pd.Series, predictions: dict[str, pd.Series]) -> pd.DataFrame:
    rows = []
    for name, pred in predictions.items():
        rows.append({"modelo": name, "MAE": round(mae(y_true, pred), 3), "RMSE": round(rmse(y_true, pred), 3)})
    return pd.DataFrame(rows).sort_values("RMSE").reset_index(drop=True)


def plot_series(series: pd.Series, train_end, out: Path, title: str) -> Path:
    fig, ax = plt.subplots(figsize=(12, 4.5))
    ax.plot(series.index, series.values, lw=0.8, color="#4C72B0", label="Temperatura media diaria")
    ax.plot(series.rolling(30).mean(), lw=2, color="#DD8452", label="Media móvil 30 días")
    ax.axvline(train_end, color="gray", ls="--", lw=1, label="Inicio del periodo de prueba")
    ax.set_title(title)
    ax.set_ylabel("°C")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)
    return out


def plot_predictions(y_true: pd.Series, predictions: dict[str, pd.Series], out: Path) -> Path:
    fig, ax = plt.subplots(figsize=(12, 4.5))
    ax.plot(y_true.index, y_true.values, color="black", lw=2, label="Real")
    styles = ["--", ":", "-."]
    for (name, pred), ls in zip(predictions.items(), styles):
        ax.plot(pred.index, pred.values, ls=ls, lw=1.5, label=name)
    ax.set_title("Periodo de prueba: real vs. predicción (un día adelante)")
    ax.set_ylabel("°C")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)
    return out


def plot_errors(y_true: pd.Series, pred: pd.Series, name: str, out: Path) -> Path:
    err = y_true - pred
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    axes[0].plot(err.index, err.values, color="#C44E52", lw=1)
    axes[0].axhline(0, color="black", lw=0.8)
    axes[0].set_title(f"Error diario ({name})")
    axes[0].set_ylabel("real - predicho (°C)")
    axes[0].grid(alpha=0.3)
    axes[1].hist(err.values, bins=20, color="#8172B3", edgecolor="white")
    axes[1].set_title("Distribución del error")
    axes[1].set_xlabel("°C")
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)
    return out
