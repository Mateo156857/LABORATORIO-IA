"""
preprocessing.py - Convierte el JSON de la API en una serie temporal limpia y validada.

Validaciones exigidas por el laboratorio:
  * tipos de datos (fechas -> datetime, valores -> float)
  * fechas duplicadas / inválidas
  * valores faltantes (se reportan y se imputan por interpolación temporal)
  * orden temporal (índice ordenado y con frecuencia diaria continua)
"""
from __future__ import annotations

import pandas as pd


def json_to_dataframe(data: dict) -> pd.DataFrame:
    """Pasa el bloque 'daily' del JSON a un DataFrame indexado por fecha."""
    df = pd.DataFrame(data["daily"])
    df["time"] = pd.to_datetime(df["time"], errors="coerce")  # fechas inválidas -> NaT
    df = df.rename(columns={"time": "date"})
    for col in df.columns.drop("date"):
        df[col] = pd.to_numeric(df[col], errors="coerce")  # texto raro -> NaN
    return df


def validate_and_clean(df: pd.DataFrame, target: str = "temperature_2m_mean") -> tuple[pd.DataFrame, dict]:
    """Limpia la serie y devuelve (df_limpio, reporte_de_calidad)."""
    report: dict = {"filas_recibidas": int(len(df))}

    # 1) Fechas inválidas
    invalid_dates = int(df["date"].isna().sum())
    df = df.dropna(subset=["date"])
    report["fechas_invalidas_eliminadas"] = invalid_dates

    # 2) Duplicados de fecha
    dups = int(df["date"].duplicated().sum())
    df = df.drop_duplicates(subset="date", keep="first")
    report["fechas_duplicadas_eliminadas"] = dups

    # 3) Orden temporal
    report["venia_ordenada"] = bool(df["date"].is_monotonic_increasing)
    df = df.sort_values("date").set_index("date")

    # 4) Frecuencia diaria continua (huecos de calendario -> NaN)
    full_index = pd.date_range(df.index.min(), df.index.max(), freq="D")
    report["dias_faltantes_en_calendario"] = int(len(full_index) - len(df))
    df = df.reindex(full_index)
    df.index.name = "date"

    # 5) Valores faltantes en la variable objetivo
    missing = int(df[target].isna().sum())
    report["faltantes_objetivo_antes"] = missing
    # Interpolación temporal: solo usa vecinos inmediatos; se hace ANTES de dividir,
    # pero con limit para no inventar tramos largos.
    df[target] = df[target].interpolate(method="time", limit=3)
    df = df.dropna(subset=[target])
    report["faltantes_objetivo_despues"] = int(df[target].isna().sum())

    # 6) Rango físico plausible para temperatura (control de calidad simple)
    out_of_range = int(((df[target] < -60) | (df[target] > 60)).sum())
    report["valores_fuera_de_rango"] = out_of_range
    df = df[(df[target] >= -60) & (df[target] <= 60)]

    report["filas_finales"] = int(len(df))
    report["fecha_inicio"] = str(df.index.min().date())
    report["fecha_fin"] = str(df.index.max().date())
    report["dtype_objetivo"] = str(df[target].dtype)
    return df, report


def train_test_split_temporal(series: pd.Series, test_days: int = 90) -> tuple[pd.Series, pd.Series]:
    """Divide respetando el orden: el test son los ÚLTIMOS días. Nunca se mezcla."""
    if test_days >= len(series):
        raise ValueError("test_days debe ser menor que el tamaño de la serie")
    train = series.iloc[:-test_days]
    test = series.iloc[-test_days:]
    assert train.index.max() < test.index.min(), "Fuga temporal: train debe terminar antes de test"
    return train, test
