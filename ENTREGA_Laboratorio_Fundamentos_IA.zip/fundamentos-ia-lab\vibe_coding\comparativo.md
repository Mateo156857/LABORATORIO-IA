# Comparativo de Vibe Coding (Componente 3)

**Problema y prompt común:** ver [`prompt.md`](prompt.md).
**Fecha de prueba:** 22/09/2026

| Rol | Modelo | Herramienta | Dónde corre |
|---|---|---|---|
| Local generalista | `llama3.2:3b` (Q4_K_M) | Ollama | CPU del equipo (16 GB RAM) |
| Local de código | `qwen2.5-coder:3b` (Q4_K_M) | Ollama | CPU del equipo (16 GB RAM) |
| Cloud de código | Claude (Anthropic), ID de configuración `claude-opus-5-5` | Claude (agente con ejecución de código) | Nube de Anthropic |

## Ciclo de trabajo

```
PROBLEMA -> PROMPT -> MODELO -> CÓDIGO -> EJECUCIÓN -> ERROR/RESULTADO -> CORRECCIÓN -> SOLUCIÓN
```

## Tabla comparativa (ejecución real del 22/09/2026)

Procedimiento automatizado con `vibe_local.py`: mismo prompt → código → ejecución → si falla, se le
devuelve **solo el error** al modelo (máximo 3 iteraciones). Registro en `evidence/vibe_coding/registro_vibe_local.json`.

| Criterio | Local general (llama3.2:3b) | Local coding (qwen2.5-coder:3b) | Cloud coding (Claude) |
|---|---|---|---|
| **Código ejecutable** | Sí, al primer intento. Obtuvo los datos reales (168 registros) y generó `temperatura.png` | No, según el criterio automático. El intento 3 sí corre (la gráfica se abrió en pantalla), pero se queda bloqueado en `plt.show()` y guarda `temperature.png` en vez del nombre pedido | Sí, al primer intento. Con datos reales: mín 10,2, máx 21,1, media 14,84 y desv. 3,19 °C |
| **Errores encontrados** | Ninguno de ejecución. **Errores de requisitos:** rechaza toda la respuesta si hay un nulo (el prompt pedía ignorarlos); no calcula la media por día ("temperatura media" repite la media global); el eje X muestra 168 etiquetas de texto | 1) `AttributeError: 'list' object has no attribute 'reshape'` (usa numpy sobre una lista). 2) `AttributeError: 'tuple' object has no attribute 'min'` (desempaquetado mal hecho). 3) Timeout por `plt.show()`. Además, la validación falla con nulos y calcula las medias diarias pero no las imprime | Ninguno en ejecución ni en las pruebas |
| **Iteraciones necesarias** | 1 | 3 (sin cumplir por completo) | 1 |
| **Tiempo hasta solución** | 94 s (88 s de generación en CPU) | 545 s (107 + 145 + 167 s de generación) sin solución válida | ≈ 3 min, incluida la escritura de pruebas |
| **Calidad/claridad del código** | Funciones separadas y nombres en español, pero repite 5 veces la misma lista por comprensión; importa pandas y no lo usa | Buena estructura (fetch/validate/stats/plot), pero asume sin verificar que hay exactamente 24×7 datos (`reshape(-1, 24)`) | Funciones separadas, tipado, pandas para agrupar por día y manejo explícito de errores |
| **Documentación** | Sin docstrings ni comentarios | Un comentario por bloque | Docstrings por función y uso en la cabecera |
| **Pruebas sugeridas/generadas** | Sí, sugirió pruebas con pytest en la respuesta | Sí, sugirió pruebas con pytest en cada intento | 3 pruebas con pytest que pasan (nulos, tamaños distintos, sin `hourly`) |
| **Intervención humana necesaria** | Media: corregir el manejo de nulos y agregar la media diaria para cumplir el requisito 3 | Alta: quitar `plt.show()`, corregir el nombre del archivo, imprimir las medias diarias y manejar los nulos | Baja: revisar el código y ejecutarlo contra la API real |

**Evidencia:** en `vibe_coding/solucion_local_general/` y `vibe_coding/solucion_local_coding/` están las respuestas
completas (`respuesta_N.md`), cada intento (`intento_N.py`) y las gráficas. La solución cloud está en `solucion_cloud/`.

## Reflexión técnica

1. **"Ejecuta" no es lo mismo que "cumple".** El modelo generalista produjo código que corrió a la
   primera, pero al revisarlo contra el prompt incumple dos requisitos: ignorar nulos y calcular
   la media diaria. Solo la verificación humana lo detecta. Un criterio automático de "corrió sin
   error" habría dado una conclusión falsa.
2. **La especialización no garantizó el resultado en esta tarea.** En la prueba corta de
   programación (media móvil), qwen2.5-coder acertó y llama3.2 falló. En esta tarea más larga
   pasó lo contrario: qwen2.5-coder encadenó errores de tipos (lista vs. arreglo numpy, tupla vs.
   arreglo) y, al corregir uno, no arregló la causa de fondo. Con modelos de 3B los resultados
   varían mucho entre tareas, así que una sola prueba no basta para declarar un ganador.
3. **Correcciones que se quedan en el síntoma.** En cada iteración el modelo local corrigió
   exactamente la línea del error, sin revisar el resto del programa. El modelo cloud escribió y
   ejecutó sus propias pruebas antes de entregar, cerrando parte del ciclo por sí mismo.
4. **Costo del ciclo en CPU.** Cada iteración local tardó entre 1,5 y 3 minutos solo en generar
   código (~14 tokens/s). Tres iteraciones fallidas costaron 9 minutos. El modelo cloud es mucho
   más rápido y preciso, pero requiere enviar el código a un tercero y depende de una cuenta de pago.
5. **Responsabilidad humana.** En los tres casos la decisión final fue del equipo: revisar el
   código contra los requisitos, entender por qué falló y decidir qué corregir. La IA propuso;
   el equipo verificó.
