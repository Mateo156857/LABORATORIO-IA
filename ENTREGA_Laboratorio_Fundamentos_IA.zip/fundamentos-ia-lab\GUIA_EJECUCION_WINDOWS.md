# Guía de ejecución en Windows (paso a paso)

Equipo: Windows, 16 GB de RAM, gráficos integrados. Tiempo total estimado: 45–60 min.
📸 = tomar captura y guardarla en la carpeta de `evidence\` que se indica.

Abrir **cmd** y ubicarse en el proyecto:
```
cd %USERPROFILE%\Desktop\fundamentos-ia-lab
python -m pip install -r requirements.txt
python -m pytest -q
```
📸 `evidence\` – las 8 pruebas pasan.

---

## Parte A – Ollama (≈ 15 min)

```
ollama --version
ollama pull llama3.2:3b
ollama pull qwen2.5-coder:3b
ollama list
```
📸 `evidence\ollama\` – versión y lista de modelos.

```
ollama run llama3.2:3b
```
Preguntar: *¿Qué es una ventana de contexto?* 📸 Salir con `/bye`.

```
ollama run qwen2.5-coder:3b
```
Pedir: *Escribe una función en Python que calcule la media móvil.* 📸

Mientras responde, abrir el Administrador de tareas (Ctrl+Shift+Esc) → Rendimiento → Memoria. 📸

```
python modelos_locales\ollama_test.py
```
📸 Captura de la terminal. Queda un registro en `evidence\registro_modelos_locales.csv`.

## Parte B – LM Studio (≈ 15 min)

1. Descargar e instalar LM Studio desde https://lmstudio.ai
2. Pestaña **Discover** (lupa) → buscar **Llama 3.2 3B Instruct** → descargar la variante **Q4_K_M**. 📸
3. Pestaña **Chat** → cargar el modelo → hacer las mismas 2 preguntas de la Parte A. 📸 En la parte inferior LM Studio muestra los tokens/s y la RAM.
4. Pestaña **Developer** → seleccionar el modelo → **Start Server** (puerto 1234). 📸
5. En cmd:
```
python modelos_locales\lmstudio_test.py
```
📸 `evidence\lmstudio\`

6. Abrir `evidence\registro_modelos_locales.csv` en Excel y copiar los valores a `modelos_locales\registro_tecnico.md`.

## Parte C – Reto integrador (≈ 2 min)

```
python serie_temporal\app.py
```
Esto descarga los datos reales de Open-Meteo y crea, en `evidence\serie_temporal\`:
`respuesta_api_raw.json`, `serie_limpia.csv`, `metricas.csv`, las 3 gráficas y `resumen_ejecucion.json`.
📸 Captura de la terminal. Copiar las métricas a la tabla de resultados del `README.md`.

## Parte D – Vibe Coding (≈ 20 min)

1. Solución cloud (ya hecha):
```
python vibe_coding\solucion_cloud\clima_stats.py
```
📸 `evidence\vibe_coding\cloud_ejecucion.png`

2. Modelos locales: abrir `vibe_coding\prompt.md` y copiar el prompt.
   - `ollama run llama3.2:3b` → pegar el prompt → **iniciar cronómetro**.
   - Copiar el código a `vibe_coding\solucion_local_general\clima_stats.py` y ejecutarlo.
   - Si falla, pegarle al modelo el error y contar la iteración. Máximo 3 iteraciones; si no funciona, anotarlo como "no ejecutable".
   - 📸 Captura de cada error y del resultado final.
   - Repetir con `qwen2.5-coder:3b` → `vibe_coding\solucion_local_coding\`.
3. Llenar las columnas locales de `vibe_coding\comparativo.md`.

## Parte E – Entrega

```
git init
git add .
git commit -m "Laboratorio Fundamentos IA"
```
Subir el repositorio a GitHub (o entregar el .zip) y revisar que **no haya ningún archivo `.env` con secretos**.

## Preguntas que el docente puede hacer (preparar)

- ¿Qué diferencia hay entre Ollama y llama3.2? → Ollama es el *runtime* y el servidor; llama3.2 es el *modelo*, es decir, los pesos.
- ¿Qué es Q4_K_M? → Cuantización a ~4 bits por peso: el modelo pasa de ~6 GB a ~2 GB con poca pérdida de calidad.
- ¿Por qué no usaron `train_test_split` aleatorio? → Porque mezclaría el futuro con el pasado (fuga temporal).
- ¿Por qué `shift(1)` en la media móvil? → Para que el valor del día que se predice no entre en su propia predicción.
- ¿Qué significa un MAE de 0,8? → Que en promedio la predicción se equivoca en 0,8 °C.
- ¿Por qué RMSE ≥ MAE? → El RMSE eleva los errores al cuadrado, así que castiga más los errores grandes.
