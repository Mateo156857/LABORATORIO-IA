"""
ollama_test.py - Consume modelos locales servidos por Ollama mediante su API REST local.

    MODELO (GGUF) -> OLLAMA (runtime/servidor) -> API LOCAL http://localhost:11434 -> ESTE PROGRAMA

Requisitos previos (en una terminal):
    ollama pull llama3.2:3b          # modelo generalista
    ollama pull qwen2.5-coder:3b     # modelo de código
Uso:
    python modelos_locales/ollama_test.py
    python modelos_locales/ollama_test.py --models llama3.2:3b --prompt "Hola, ¿quién eres?"
"""
from __future__ import annotations

import argparse
import time

import requests

from common import PROMPTS, append_log, environment_info, ram_snapshot

OLLAMA_URL = "http://localhost:11434"


def list_local_models() -> list[dict]:
    r = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10)
    r.raise_for_status()
    return r.json().get("models", [])


def generate(model: str, prompt: str, temperature: float = 0.2) -> dict:
    """POST /api/generate sin streaming. Devuelve texto + métricas que reporta Ollama."""
    t0 = time.perf_counter()
    r = requests.post(
        f"{OLLAMA_URL}/api/generate",
        json={"model": model, "prompt": prompt, "stream": False, "options": {"temperature": temperature}},
        timeout=600,
    )
    r.raise_for_status()
    wall = time.perf_counter() - t0
    data = r.json()
    eval_count = data.get("eval_count", 0)
    eval_s = data.get("eval_duration", 0) / 1e9
    return {
        "respuesta": data.get("response", ""),
        "tiempo_total_s": round(wall, 2),
        "carga_modelo_s": round(data.get("load_duration", 0) / 1e9, 2),
        "tokens_generados": eval_count,
        "tokens_por_segundo": round(eval_count / eval_s, 2) if eval_s else None,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="+", default=["llama3.2:3b", "qwen2.5-coder:3b"])
    ap.add_argument("--prompt", default=None, help="una sola consulta en vez del set estándar")
    a = ap.parse_args()

    print("Entorno:", environment_info())
    try:
        local = list_local_models()
    except requests.ConnectionError:
        raise SystemExit("No se pudo conectar con Ollama en localhost:11434. ¿Está abierto/instalado?")

    print("\nModelos instalados en Ollama:")
    quant = {}
    for m in local:
        det = m.get("details", {})
        quant[m["name"]] = det.get("quantization_level", "")
        print(f"  - {m['name']:<25} {det.get('parameter_size', ''):>6}  {det.get('quantization_level', '')}"
              f"  {m.get('size', 0) / 1024**3:.2f} GB")

    prompts = [("libre", a.prompt)] if a.prompt else PROMPTS
    for model in a.models:
        for tipo, prompt in prompts:
            print("\n" + "=" * 80 + f"\nMODELO: {model} | tipo: {tipo}\nPROMPT: {prompt}\n" + "-" * 80)
            res = generate(model, prompt)
            ram = ram_snapshot()
            print(res["respuesta"])
            print(f"\n>> tiempo {res['tiempo_total_s']} s | carga {res['carga_modelo_s']} s | "
                  f"{res['tokens_por_segundo']} tok/s | RAM runtime {ram['ram_procesos_runtime_mb']} MB | "
                  f"RAM sistema {ram['ram_sistema_usada_gb']}/{ram['ram_sistema_total_gb']} GB")
            append_log("registro_modelos_locales.csv", {
                "herramienta": "Ollama", "modelo": model, "cuantizacion": quant.get(model, ""),
                "tipo_prompt": tipo, "prompt": prompt[:60],
                **{k: v for k, v in res.items() if k != "respuesta"}, **ram,
                "respuesta_inicio": res["respuesta"][:120].replace("\n", " "),
            })
    print("\nRegistro guardado en evidence/registro_modelos_locales.csv")


if __name__ == "__main__":
    main()
