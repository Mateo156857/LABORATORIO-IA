"""
vibe_local.py - Ejecuta el ciclo de Vibe Coding con los modelos LOCALES de Ollama, registrando todo.

Ciclo: PROBLEMA -> PROMPT -> MODELO -> CÓDIGO -> EJECUCIÓN -> ERROR/RESULTADO -> CORRECCIÓN -> SOLUCIÓN

Para cada modelo:
  1. Envía el prompt común (vibe_coding/prompt.md) vía API local de Ollama.
  2. Extrae el bloque de código Python de la respuesta y lo guarda (intento_N.py).
  3. Lo ejecuta. Si falla, le devuelve al modelo SOLO el error y repite (máx. 3 iteraciones).
  4. Registra tiempos, errores e iteraciones en evidence/vibe_coding/registro_vibe_local.json.

Uso:  python vibe_coding/vibe_local.py
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
OLLAMA = "http://localhost:11434/api/chat"
MODELS = {"local_general": os.getenv("GENERAL_MODEL", "llama3.2:3b"),
          "local_coding": os.getenv("CODER_MODEL", "qwen2.5-coder:3b")}
MAX_ITER = 3


def load_prompt() -> str:
    text = (ROOT / "vibe_coding" / "prompt.md").read_text(encoding="utf-8")
    return text.split("```", 2)[1].strip()  # el primer bloque ``` es el prompt


def ask(model: str, messages: list[dict]) -> tuple[str, float]:
    t0 = time.perf_counter()
    r = requests.post(OLLAMA, json={"model": model, "messages": messages, "stream": False,
                                    "options": {"temperature": 0.2}}, timeout=1800)
    r.raise_for_status()
    return r.json()["message"]["content"], time.perf_counter() - t0


def extract_code(answer: str) -> str:
    blocks = re.findall(r"```(?:python|py)?\s*\n(.*?)```", answer, flags=re.S)
    if not blocks:
        return answer
    # el bloque principal suele ser el más largo; las pruebas pytest se ignoran para ejecutar
    main = [b for b in blocks if "def test_" not in b] or blocks
    return max(main, key=len)


def run_code(path: Path) -> tuple[bool, str]:
    try:
        p = subprocess.run([sys.executable, path.name], cwd=path.parent, capture_output=True,
                           text=True, timeout=120, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        return False, "TimeoutExpired: el programa tardó más de 120 s"
    out = (p.stdout + "\n" + p.stderr).strip()
    ok = p.returncode == 0 and (path.parent / "temperatura.png").exists()
    return ok, out[-3000:]


def main() -> None:
    prompt = load_prompt()
    log = {}
    for folder, model in MODELS.items():
        out_dir = ROOT / "vibe_coding" / f"solucion_{folder}"
        out_dir.mkdir(exist_ok=True)
        (out_dir / "temperatura.png").unlink(missing_ok=True)
        messages = [{"role": "user", "content": prompt}]
        rec = {"modelo": model, "iteraciones": [], "exito": False}
        t_start = time.perf_counter()
        print("=" * 80 + f"\n{model}")
        for i in range(1, MAX_ITER + 1):
            answer, secs = ask(model, messages)
            (out_dir / f"respuesta_{i}.md").write_text(answer, encoding="utf-8")
            code = extract_code(answer)
            f = out_dir / f"intento_{i}.py"
            f.write_text(code, encoding="utf-8")
            ok, output = run_code(f)
            print(f"  iteración {i}: {secs:.0f} s de generación -> {'OK' if ok else 'FALLÓ'}")
            if not ok:
                print("   ", output.splitlines()[-1] if output else "(sin salida)")
            rec["iteraciones"].append({"n": i, "segundos_generacion": round(secs, 1), "ok": ok,
                                       "salida_o_error": output[-800:], "lineas_codigo": code.count("\n") + 1,
                                       "genero_pytest": "def test_" in answer})
            if ok:
                (out_dir / "clima_stats.py").write_text(code, encoding="utf-8")
                rec["exito"] = True
                break
            messages += [{"role": "assistant", "content": answer},
                         {"role": "user", "content": f"Al ejecutar el código obtengo este error, corrígelo y devuelve el archivo completo:\n{output[-1500:]}"}]
        rec["tiempo_total_s"] = round(time.perf_counter() - t_start, 1)
        log[folder] = rec
    dest = ROOT / "evidence" / "vibe_coding" / "registro_vibe_local.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nRegistro: {dest}")


if __name__ == "__main__":
    main()
