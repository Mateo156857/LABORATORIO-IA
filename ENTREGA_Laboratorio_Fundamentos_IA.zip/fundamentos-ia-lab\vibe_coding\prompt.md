# Problema y prompt común de Vibe Coding

> Si el docente entregó un problema distinto, reemplazar este texto y repetir el proceso.
> Lo importante es que **los tres modelos reciban exactamente el mismo prompt inicial**.

## Problema

Consumir la API pública de pronóstico de Open-Meteo, validar la respuesta,
calcular estadísticas básicas de la temperatura horaria de los próximos 7 días
en Bogotá y generar una gráfica.

## Prompt inicial (copiar tal cual en los tres modelos)

```
Escribe un programa en Python 3 (un solo archivo llamado clima_stats.py) que:

1. Consuma la API pública de Open-Meteo:
   https://api.open-meteo.com/v1/forecast?latitude=4.61&longitude=-74.08&hourly=temperature_2m&forecast_days=7&timezone=America/Bogota
   (no requiere API key).
2. Valide la respuesta: código HTTP 200, que exista hourly.time y hourly.temperature_2m,
   que ambas listas tengan el mismo tamaño y que las temperaturas sean numéricas (ignorar nulos).
3. Calcule: mínimo, máximo, media, desviación estándar, y la temperatura media de cada día.
4. Imprima las estadísticas en consola de forma legible.
5. Genere una gráfica con matplotlib de la temperatura horaria con una línea horizontal
   en la media, y la guarde como temperatura.png.
6. Maneje errores de red con un mensaje claro.
Usa solo requests, pandas y matplotlib. Incluye comentarios breves y al menos 2 pruebas con pytest
para la función de validación.
```

## Reglas de la prueba

- Mismo prompt inicial en: modelo local generalista (`llama3.2:3b`),
  modelo local de código (`qwen2.5-coder:3b`) y modelo cloud (Claude).
- Cronometrar desde que se envía el prompt hasta tener un programa que corra y produzca la gráfica.
- Si el código falla, se le pega al modelo **solo el mensaje de error** y se cuenta una iteración.
- Guardar el código final de cada modelo en `vibe_coding/solucion_<modelo>/`
  y capturas en `evidence/vibe_coding/`.
