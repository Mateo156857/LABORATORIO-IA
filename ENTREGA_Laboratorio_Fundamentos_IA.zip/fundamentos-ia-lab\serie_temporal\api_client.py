"""
api_client.py - Cliente de la API pública Open-Meteo (Historical Weather API).

Fase del ciclo de vida: ANÁLISIS / IMPLEMENTACIÓN.
- Documentación oficial: https://open-meteo.com/en/docs/historical-weather-api
- No requiere API key (uso no comercial gratuito).
- Respuesta JSON con la forma:
    {
      "latitude": ..., "longitude": ..., "timezone": "America/Bogota",
      "daily_units": {"time": "iso8601", "temperature_2m_mean": "°C", ...},
      "daily": {"time": ["2023-01-01", ...], "temperature_2m_mean": [14.1, ...], ...}
    }
"""
from __future__ import annotations

import json
import os
from datetime import date, timedelta
from pathlib import Path

import requests

BASE_URL = "https://archive-api.open-meteo.com/v1/archive"

# Valores por defecto: Bogotá. Se pueden cambiar con variables de entorno (ver .env.example).
DEFAULT_LAT = float(os.getenv("LATITUDE", "4.6097"))
DEFAULT_LON = float(os.getenv("LONGITUDE", "-74.0817"))
DEFAULT_TZ = os.getenv("TIMEZONE", "America/Bogota")
DAILY_VARS = ["temperature_2m_mean", "temperature_2m_max", "temperature_2m_min", "precipitation_sum"]


def default_date_range(years: int = 3) -> tuple[str, str]:
    """El archivo histórico de Open-Meteo tiene ~5 días de retraso: terminamos hace 7 días."""
    end = date.today() - timedelta(days=7)
    start = end - timedelta(days=365 * years)
    return start.isoformat(), end.isoformat()


def fetch_daily_weather(
    start_date: str | None = None,
    end_date: str | None = None,
    latitude: float = DEFAULT_LAT,
    longitude: float = DEFAULT_LON,
    timezone: str = DEFAULT_TZ,
    timeout: int = 30,
) -> dict:
    """Descarga datos diarios reales desde Open-Meteo y devuelve el JSON como dict."""
    if start_date is None or end_date is None:
        start_date, end_date = default_date_range()

    params = {
        "latitude": latitude,
        "longitude": longitude,
        "start_date": start_date,
        "end_date": end_date,
        "daily": ",".join(DAILY_VARS),
        "timezone": timezone,
    }
    response = requests.get(BASE_URL, params=params, timeout=timeout)
    response.raise_for_status()  # error HTTP -> excepción clara
    data = response.json()

    # Validación mínima del contrato de la API
    if data.get("error"):
        raise ValueError(f"La API devolvió un error: {data.get('reason')}")
    if "daily" not in data or "time" not in data["daily"]:
        raise ValueError("Respuesta inesperada: falta la clave 'daily' o 'daily.time'.")
    return data


def save_raw(data: dict, path: str | Path) -> Path:
    """Guarda el JSON crudo como evidencia del consumo de la API."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


if __name__ == "__main__":
    s, e = default_date_range(years=1)
    d = fetch_daily_weather(s, e)
    print(f"Registros recibidos: {len(d['daily']['time'])}  ({d['daily']['time'][0]} -> {d['daily']['time'][-1]})")
    print("Unidades:", d.get("daily_units"))
