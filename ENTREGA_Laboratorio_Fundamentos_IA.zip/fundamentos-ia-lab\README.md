# Laboratorio – Fundamentos de IA para el Desarrollo de Software Aumentado

**Curso:** Fundamentos de Inteligencia Artificial – Ingeniería de Sistemas
**Equipo:** Juan Diego Gómez Betancur · Nicolás Giraldo Tobón · Mateo Agudelo Castro
**Fecha:** 22/09/2026

> **Principio rector:** la IA propone, acelera y explica. El equipo comprende, ejecuta, verifica y justifica.

## Contenido del repositorio

| Componente | Carpeta | Entregable |
|---|---|---|
| 0. Mapa mental (15 %) | `mapa_mental/` | `mapa_mental.png` / `.pdf` + explicación de relaciones |
| 1. Cartografía (20 %) | `cartografia_modelos/` | `modelos.csv` (20 modelos, 6 categorías, con fuentes) + `cartografia.md` |
| 2. Ollama + LM Studio (20 %) | `modelos_locales/` | `ollama_test.py`, `lmstudio_test.py`, `registro_tecnico.md` |
| 3. Vibe Coding (20 %) | `vibe_coding/` | `prompt.md`, soluciones de los 3 modelos, `comparativo.md` |
| 4. Reto integrador (25 %) | `serie_temporal/` | App de series temporales con Open-Meteo |
| Pruebas | `tests/` | 8 pruebas con pytest |
| Evidencias | `evidence/` | Capturas, CSV de registros, gráficas y JSON crudo de la API |

## Instalación

Requiere Python 3.10+ y [Ollama](https://ollama.com). LM Studio se usa en el Componente 2.

```bash
pip install -r requirements.txt
pytest -q                                   # 8 pruebas deben pasar
```

No se necesita ninguna API key: Open-Meteo es pública. `.env.example` solo trae las coordenadas,
que son opcionales. **Nunca se sube un `.env` con secretos** (está en `.gitignore`).

## Ejecución

```bash
# Componente 2 - modelos locales vía API
ollama pull llama3.2:3b
ollama pull qwen2.5-coder:3b
python modelos_locales/ollama_test.py
python modelos_locales/lmstudio_test.py        # con el servidor de LM Studio encendido

# Componente 3 - solución cloud de Vibe Coding
python vibe_coding/solucion_cloud/clima_stats.py

# Componente 4 - reto integrador
python serie_temporal/app.py                   # descarga 3 años de Bogotá y genera las evidencias
```

Guía detallada para Windows: [`GUIA_EJECUCION_WINDOWS.md`](GUIA_EJECUCION_WINDOWS.md).

---

## Componente 4 – Reto integrador: temperatura diaria de Bogotá

**Flujo:** API → JSON → Python/Pandas → preparación → serie temporal → modelo → predicción → MAE/RMSE → gráficas

### Relación con el ciclo de vida clásico

| Fase | Qué hicimos |
|---|---|
| **Requisitos** | La app debe descargar la temperatura media diaria real de Bogotá (≈ 3 años), mostrarla como serie temporal y **predecir la temperatura del día siguiente**, comparándose contra baselines con MAE y RMSE. |
| **Análisis** | API: [Open-Meteo Historical Weather](https://open-meteo.com/en/docs/historical-weather-api). No requiere key. Devuelve JSON con `daily.time` (ISO 8601) y `daily.temperature_2m_mean` (°C). Restricciones: el archivo tiene ~5 días de retraso (pedimos hasta hace 7 días) y puede traer `null`. |
| **Diseño** | Módulos con una responsabilidad cada uno: `api_client.py` (descarga) → `preprocessing.py` (validación, limpieza, división temporal) → `model.py` (baselines y regresión) → `evaluation.py` (métricas y gráficas) → `app.py` (orquesta el flujo). |
| **Implementación** | Python + pandas + scikit-learn, con Vibe Coding (ver abajo). |
| **Pruebas** | `tests/test_serie_temporal.py`: tipos, orden, duplicados, huecos, faltantes, división sin fuga, métricas y una prueba que **altera el futuro y verifica que las predicciones del pasado no cambian**. |

### Validación de datos (`preprocessing.py`)

- **Tipos:** fechas con `to_datetime`, valores con `to_numeric`. Lo inválido pasa a NaT/NaN y se reporta.
- **Fechas:** se eliminan las inválidas y las duplicadas; el índice se reindexa a frecuencia diaria continua para detectar huecos.
- **Faltantes:** se cuentan y se interpolan por tiempo (máximo 3 días seguidos).
- **Orden temporal:** se registra si la serie venía ordenada y se ordena. Hay un control de rango físico (−60 a 60 °C).
- Todo queda en un **reporte de calidad** que se imprime y se guarda en `evidence/serie_temporal/resumen_ejecucion.json`.

### Modelos

| Modelo | Tipo | Cómo predice el día *t* |
|---|---|---|
| Persistencia | Baseline 1 | ŷ(t) = y(t−1) |
| Media móvil 7 días | Baseline 2 | ŷ(t) = promedio de y(t−7) … y(t−1) |
| Regresión con rezagos | Modelo predictivo | Regresión lineal sobre y(t−1), y(t−2), y(t−3), y(t−7), y(t−14), la media de 7 días y seno/coseno del día del año (estacionalidad) |

**Sin fuga temporal:** los **últimos 90 días** son el conjunto de prueba y los anteriores el de
entrenamiento, sin mezclar. La regresión se entrena solo con el periodo de entrenamiento. Todas
las variables usan `shift(≥1)`, así que para predecir el día *t* solo se usa información hasta *t−1*.

### Resultados

Ejecución real del 22/09/2026 (`evidence/serie_temporal/`):

- **Datos:** 1096 días reales de Open-Meteo, del 16/09/2023 al 15/09/2026, en lat 4,675 / lon −74,113 (Bogotá).
- **Calidad:** 0 fechas inválidas, 0 duplicados y 0 huecos. La serie venía ordenada y sin faltantes.
- **Entrenamiento:** 16/09/2023 → 17/06/2026 (1006 días).
- **Prueba:** 18/06/2026 → 15/09/2026 (90 días).

| Modelo | MAE (°C) | RMSE (°C) |
|---|---|---|
| Regresión con rezagos | 0,515 | **0,642** |
| Persistencia (baseline) | **0,502** | 0,650 |
| Media móvil 7d (baseline) | 0,534 | 0,656 |

Gráficas: `evidence/serie_temporal/01_serie_temporal.png`, `02_real_vs_prediccion.png` y `03_errores_mejor_modelo.png`.

**Interpretación.** Los tres modelos se equivocan en promedio alrededor de medio grado. La
temperatura media de Bogotá varía muy poco (entre ~13 y 16,5 °C en el periodo de prueba), así que
la **persistencia** ("mañana igual que hoy") ya es un baseline muy fuerte y obtiene el menor MAE.

La **regresión con rezagos** obtiene el menor RMSE: comete menos errores grandes porque suaviza los
cambios bruscos. Su coeficiente principal es `lag_1` = 0,59, lo que confirma que el día anterior es
la variable más informativa. La mejora sobre los baselines es pequeña (≈ 0,01 °C) y no concluyente.

Conclusión honesta: con solo la temperatura pasada como información, el modelo no le gana
claramente a la persistencia. Para mejorar habría que agregar otras variables (nubosidad,
precipitación, humedad) o predecir con más días de anticipación, donde la persistencia se degrada.

---

## Uso de IA durante el desarrollo

| Qué se le pidió a la IA | Herramienta | Qué decidió / verificó el equipo |
|---|---|---|
| Estructura del repositorio y del código del reto | Claude (cloud) | Se eligió la API Open-Meteo (sin key) y Bogotá como ciudad |
| Código de validación, modelos y métricas | Claude (cloud) | Revisamos que la división fuera temporal y que no hubiera fuga de información; ejecutamos las pruebas |
| Scripts de Ollama / LM Studio | Claude (cloud) | Elegimos modelos de 3B por tener 16 GB de RAM sin GPU; los ejecutamos y registramos los recursos |
| Vibe Coding con modelos locales | llama3.2:3b, qwen2.5-coder:3b | Contamos iteraciones y errores; corregimos a mano lo necesario |
| Cartografía y mapa mental | Claude (cloud) + fuentes oficiales | Verificamos los datos contra las páginas de los proveedores |

Todo el código fue ejecutado y revisado por el equipo antes de entregarlo.
