# Registro técnico – Modelos locales (Componente 2)

> Datos reales del 22/09/2026. Los valores numéricos salen de `evidence/registro_modelos_locales.csv`,
> que generan automáticamente `ollama_test.py` y `lmstudio_test.py`, y de las capturas del chat de LM Studio.

## Entorno utilizado

| Campo | Valor |
|---|---|
| Equipo / SO | Windows 11 (build 10.0.26200), x64 |
| CPU | Intel Core 7 150U |
| RAM | 16 GB (15,7 GiB reportados) |
| GPU | Intel Graphics integrada (sin GPU dedicada, **sin VRAM dedicada** → inferencia 100 % en CPU) |
| Versión de Ollama | 0.34.0 |
| Versión de LM Studio | LM Studio (servidor local en http://127.0.0.1:1234, API compatible con OpenAI) |
| Python | 3.14.5 |
| Fecha de prueba | 22/09/2026 |

## Por qué se eligieron estos modelos

Con 16 GB de RAM y sin GPU dedicada, todo corre en CPU. Un modelo de 3B parámetros
en cuantización Q4 pesa ~2 GB y cabe con holgura, dejando RAM para Windows, el navegador y LM Studio.
Un 7B Q4 (~4,5 GB) también cabe, pero en CPU responde unas 2-3 veces más lento.

| Rol | Herramienta | Modelo | Parámetros | Cuantización | Tamaño en disco |
|---|---|---|---|---|---|
| Generalista | Ollama | `llama3.2:3b` | 3,2 B | Q4_K_M | ~2,0 GB |
| Código | Ollama | `qwen2.5-coder:3b` | 3,1 B | Q4_K_M | ~1,9 GB |
| Generalista | LM Studio | Llama 3.2 3B Instruct (GGUF) | 3,2 B | Q4_K_M | ~2,0 GB |

## Resultados (consultas equivalentes en ambos entornos)

| Herramienta | Modelo | Consulta | Tiempo (s) | Tokens/s | RAM runtime (MB) | RAM sistema (GB) | ¿Respuesta correcta? |
|---|---|---|---|---|---|---|---|
| Ollama | llama3.2:3b | Ventana de contexto | 18,8 (incluye 6,3 s de carga) | 14,4 | 3461 | 13,97 / 15,73 | ❌ La confunde con los datos de entrenamiento |
| Ollama | llama3.2:3b | Entrenamiento vs inferencia | 35,3 | 14,4 | 3479 | 13,87 / 15,73 | ✅ Correcta, con ejemplo perros/gatos |
| Ollama | llama3.2:3b | Media móvil en Python | 12,4 | 14,9 | 3468 | 13,95 / 15,73 | ❌ Devuelve un solo número con una fórmula recursiva incorrecta; dice que la salida es 5.0 y no lo es |
| Ollama | llama3.2:3b | Explicar división por cero | 46,0 | 14,2 | 3479 | 13,82 / 15,73 | ⚠️ Detecta el `ZeroDivisionError`, pero agrega una "mejora" errónea (prohíbe divisores negativos) |
| Ollama | qwen2.5-coder:3b | Ventana de contexto | 12,5 (incluye 5,0 s de carga) | 14,9 | 5605* | 14,93 / 15,73 | ❌ También la confunde con datos de entrenamiento |
| Ollama | qwen2.5-coder:3b | Entrenamiento vs inferencia | 26,5 | 15,6 | 5609* | 14,83 / 15,73 | ✅ Correcta, con ejemplo de spam |
| Ollama | qwen2.5-coder:3b | Media móvil en Python | 48,4 | 14,0 | 5621* | 14,96 / 15,73 | ✅ Correcta: lista de medias por ventana, validación y ejemplo verificado (20, 30, …, 80) |
| Ollama | qwen2.5-coder:3b | Explicar división por cero | 22,0 | 15,4 | 5647* | 14,94 / 15,73 | ✅ Detecta el error y propone una validación razonable |
| LM Studio (chat) | Llama 3.2 3B Instruct Q4_K_M | Ventana de contexto | ≈ 8,8 (136 tok ÷ 15,5 tok/s) | 15,5 | ver script | ver script | ✅ Correcta esta vez (en Ollama, el mismo modelo falló) |
| LM Studio (chat) | Llama 3.2 3B Instruct Q4_K_M | Entrenamiento vs inferencia | ≈ 18,3 | 15,9 | ver script | ver script | ✅ Correcta (dice "texto etiquetado", impreciso para un LLM) |
| LM Studio (chat) | Llama 3.2 3B Instruct Q4_K_M | Media móvil en Python | ≈ 25,4 | 15,1 | ver script | ver script | ❌ Devuelve un solo número (promedio de las sumas, sin dividir por 3); nombre con error "media_mostral"; el ejemplo no imprime |
| LM Studio (chat) | Llama 3.2 3B Instruct Q4_K_M | Explicar división por cero | ≈ 28,7 | 15,0 | ver script | ver script | ⚠️ Detecta el ZeroDivisionError, pero con afirmaciones erróneas ("entre 0 y −1", "números enteros") |
| LM Studio (API, lmstudio_test.py) | llama-3.2-3b-instruct Q4_K_M | Ventana de contexto | 24,1 | ~5,4** | 5865 | 15,17 / 15,73 | ✅ Correcta en la definición, pero dice "512 caracteres" (son tokens) |
| LM Studio (API) | llama-3.2-3b-instruct Q4_K_M | Entrenamiento vs inferencia | 43,0 | ~12,8 | 5933 | 14,81 / 15,73 | ✅ Correcta |
| LM Studio (API) | llama-3.2-3b-instruct Q4_K_M | Media móvil en Python | 36,1 | ~13,8 | 5923 | 14,55 / 15,73 | ✅ Correcta esta vez: lista de medias por ventana, docstring y ejemplo con `print` |
| LM Studio (API) | llama-3.2-3b-instruct Q4_K_M | Explicar división por cero | 33,2 | ~13,7 | 5984 | 14,56 / 15,73 | ✅ Detecta el ZeroDivisionError |

\*\* En la API de LM Studio, los tokens/s se calculan como tokens ÷ tiempo total de la petición, que incluye procesar el prompt. La primera petición es más lenta (5,4 tok/s) porque el sistema estaba casi sin RAM libre (15,2 de 15,7 GB): LM Studio y Ollama estaban abiertos al mismo tiempo.

\* La RAM del runtime suma los procesos de Ollama. Al pasar al segundo modelo, el primero seguía cargado
en memoria (Ollama lo mantiene ~5 min), por eso sube a ~5,6 GB. Cada modelo 3B Q4 ocupa ~2–3,5 GB en RAM.

Fuente: `evidence/registro_modelos_locales.csv` y `evidence/ollama/salida_ollama_test.txt` (22/09/2026).

## Relación MODELO → RUNTIME → API → APLICACIÓN

```
 Archivo del modelo (pesos GGUF cuantizados, ~2 GB en disco)
        │  se carga en RAM
        ▼
 Runtime / servidor: Ollama (llama.cpp)  |  LM Studio (llama.cpp)
        │  expone
        ▼
 API local HTTP: localhost:11434/api/generate  |  localhost:1234/v1/chat/completions (formato OpenAI)
        │  consumida por
        ▼
 Aplicación: ollama_test.py / lmstudio_test.py (requests + JSON)
```

- **Modelo**: los pesos entrenados. Por sí solo no “hace” nada: es un archivo.
- **Runtime**: el programa que carga los pesos en memoria y ejecuta la inferencia (token por token).
- **API**: el contrato HTTP/JSON para pedirle respuestas al runtime.
- **Aplicación**: nuestro código, que construye el prompt, llama a la API y usa la respuesta.

## Observaciones

- La **primera** consulta a cada modelo tarda más porque incluye cargarlo en RAM (`carga_modelo_s`).
- **Velocidad en CPU:** ~14–15,6 tokens/s con ambos modelos 3B, sin GPU. Una respuesta larga (~600 tokens) tarda ~45 s.
- **Memoria:** con los dos modelos cargados, el sistema llegó a 14,9 de 15,7 GB usados. En este equipo no conviene tener más de un modelo 3B cargado junto al navegador, y un 7B sería el límite.
- **Generalista vs. código:** para la tarea de programación, el modelo de código (**qwen2.5-coder**) acertó y el generalista (**llama3.2**) produjo una función incorrecta con una salida inventada. Mismo tamaño, distinta especialización, distinto resultado.
- **Alucinación conceptual:** **ambos** modelos definieron mal la "ventana de contexto". Los modelos pequeños pueden sonar seguros y estar equivocados, así que toda respuesta debe verificarse.
- **Ollama vs. LM Studio:** se usó **el mismo archivo GGUF** en ambos (el blob `sha256-dde5aa3fc5ff…` de Ollama se enlazó con un *hard link* en la carpeta de modelos de LM Studio, sin descargarlo otra vez). La velocidad fue prácticamente igual (Ollama 14,2–14,9 tok/s vs. LM Studio 15,0–15,9 tok/s), porque ambos usan llama.cpp como motor. Las diferencias están en la interfaz: Ollama es CLI + API propia, y LM Studio es GUI + API compatible con OpenAI.
- **No determinismo:** el mismo modelo definió mal la "ventana de contexto" en Ollama y bien en LM Studio, y en ambos falló la media móvil. Las respuestas cambian entre ejecuciones (muestreo con temperatura), así que una sola prueba no basta para evaluar un modelo.
- **Chat vs. API en LM Studio:** en el chat, el modelo escribió mal la media móvil; por la API, con temperatura 0,2, la escribió bien. Mismo modelo, mismo archivo, distinto resultado: otra evidencia de que las salidas no son deterministas.
- **RAM:** con Ollama y LM Studio abiertos a la vez, el sistema llegó a 15,2 de 15,7 GB. En este equipo conviene usar un solo runtime a la vez.
- En LM Studio, el tiempo que muestra el chat (1–5 s) es el tiempo hasta el primer token. El tiempo total se estima como tokens ÷ tokens/s.
