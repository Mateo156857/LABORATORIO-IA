"""
lmstudio_test.py - Consume un modelo cargado en LM Studio mediante su API local
compatible con OpenAI.

    MODELO (GGUF) -> LM STUDIO (runtime/servidor) -> API LOCAL http://localhost:1234/v1 -> ESTE PROGRAMA

Requisitos previos:
    1. En LM Studio descargar p.ej. "Llama 3.2 3B Instruct" (GGUF Q4_K_M).
    2. Pestaña "Developer" -> cargar el modelo -> "Start Server" (puerto 1234).
Uso:
    python modelos_locales/lmstudio_test.py
    python modelos_locales/lmstudio_test.py --model llama-3.2-3b-instruct
"""
from __future__ import annotations

import argparse
import time

import requests

from common import PROMPTS, append_log, environment_info, ram_snapshot

LMSTUDIO_URL = "http://localhost:1234/v1"


def list_models() -> list[str]:
    r = requests.get(f"{LMSTUDIO_URL}/models", timeout=10)
    r.raise_for_status()
    return [m["id"] for m in r.json().get("data", [])]


def chat(model: str, prompt: str, temperature: float = 0.2) -> dict:
    """POST /v1/chat/completions (mismo formato que la API de OpenAI)."""
    t0 = time.perf_counter()
    r = requests.post(
        f"{LMSTUDIO_URL}/chat/completions",
        json={"model": model, "messages": [{"role": "user", "content": prompt}],
              "temperature": temperature, "stream": False},
        timeout=600,
    )
    r.raise_for_status()
    wall = time.perf_counter() - t0
    data = r.json()
    usage = data.get("usage", {})
    completion = usage.get("completion_tokens", 0)
    return {
        "respuesta": data["choices"][0]["message"]["content"],
        "tiempo_total_s": round(wall, 2),
        "carga_modelo_s": "",
        "tokens_generados": completion,
        "tokens_por_segundo": round(completion / wall, 2) if wall else None,  # aprox. (incluye procesar prompt)
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=None, help="id del modelo; por defecto el primero cargado")
    ap.add_argument("--quant", default="Q4_K_M", help="cuantización del GGUF cargado (se ve en LM Studio)")
    a = ap.parse_args()

    print("Entorno:", environment_info())
    try:
        models = list_models()
    except requests.ConnectionError:
        raise SystemExit("No hay servidor en localhost:1234. En LM Studio: Developer -> Start Server.")
    print("Modelos disponibles en LM Studio:", models)
    model = a.model or models[0]

    for tipo, prompt in PROMPTS:
        print("\n" + "=" * 80 + f"\nMODELO: {model} | tipo: {tipo}\nPROMPT: {prompt}\n" + "-" * 80)
        res = chat(model, prompt)
        ram = ram_snapshot()
        print(res["respuesta"])
        print(f"\n>> tiempo {res['tiempo_total_s']} s | ~{res['tokens_por_segundo']} tok/s | "
              f"RAM runtime {ram['ram_procesos_runtime_mb']} MB | "
              f"RAM sistema {ram['ram_sistema_usada_gb']}/{ram['ram_sistema_total_gb']} GB")
        append_log("registro_modelos_locales.csv", {
            "herramienta": "LM Studio", "modelo": model, "cuantizacion": a.quant,
            "tipo_prompt": tipo, "prompt": prompt[:60],
            **{k: v for k, v in res.items() if k != "respuesta"}, **ram,
            "respuesta_inicio": res["respuesta"][:120].replace("\n", " "),
        })
    print("\nRegistro guardado en evidence/registro_modelos_locales.csv")


if __name__ == "__main__":
    main()
