"""
clima_stats.py - Solución generada por el modelo cloud (Claude, Anthropic) a partir del prompt común.

Consume el pronóstico horario de Open-Meteo, valida la respuesta, calcula estadísticas y grafica.
Uso:  python vibe_coding/solucion_cloud/clima_stats.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import requests

URL = "https://api.open-meteo.com/v1/forecast"
PARAMS = {
    "latitude": 4.61,
    "longitude": -74.08,
    "hourly": "temperature_2m",
    "forecast_days": 7,
    "timezone": "America/Bogota",
}


def fetch(url: str = URL, params: dict = PARAMS) -> dict:
    """Descarga el JSON. Lanza RuntimeError con mensaje claro si falla la red o el HTTP."""
    try:
        r = requests.get(url, params=params, timeout=20)
    except requests.RequestException as exc:
        raise RuntimeError(f"No se pudo conectar con Open-Meteo: {exc}") from exc
    if r.status_code != 200:
        raise RuntimeError(f"Open-Meteo respondió HTTP {r.status_code}: {r.text[:200]}")
    return r.json()


def validate(data: dict) -> pd.DataFrame:
    """Verifica la estructura y devuelve un DataFrame limpio (time, temp)."""
    hourly = data.get("hourly")
    if not isinstance(hourly, dict):
        raise ValueError("La respuesta no contiene 'hourly'.")
    times, temps = hourly.get("time"), hourly.get("temperature_2m")
    if times is None or temps is None:
        raise ValueError("Faltan 'hourly.time' o 'hourly.temperature_2m'.")
    if len(times) != len(temps):
        raise ValueError(f"Tamaños distintos: {len(times)} fechas vs {len(temps)} temperaturas.")
    df = pd.DataFrame({"time": pd.to_datetime(times, errors="coerce"),
                       "temp": pd.to_numeric(pd.Series(temps), errors="coerce")})
    df = df.dropna().sort_values("time").reset_index(drop=True)  # ignora nulos / no numéricos
    if df.empty:
        raise ValueError("No hay temperaturas válidas en la respuesta.")
    return df


def compute_stats(df: pd.DataFrame) -> dict:
    daily = df.groupby(df["time"].dt.date)["temp"].mean().round(2)
    return {
        "n": len(df),
        "min": round(df["temp"].min(), 2),
        "max": round(df["temp"].max(), 2),
        "media": round(df["temp"].mean(), 2),
        "desv_std": round(df["temp"].std(), 2),
        "media_diaria": daily,
    }


def plot(df: pd.DataFrame, mean: float, out: Path = Path("temperatura.png")) -> Path:
    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(df["time"], df["temp"], label="Temperatura horaria")
    ax.axhline(mean, color="red", ls="--", label=f"Media = {mean:.1f} °C")
    ax.set_title("Pronóstico horario 7 días - Bogotá (Open-Meteo)")
    ax.set_ylabel("°C")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out, dpi=120)
    plt.close(fig)
    return out


def main() -> int:
    try:
        df = validate(fetch())
    except (RuntimeError, ValueError) as exc:
        print(f"ERROR: {exc}")
        return 1
    s = compute_stats(df)
    print(f"Registros válidos: {s['n']}")
    print(f"Mínimo: {s['min']} °C | Máximo: {s['max']} °C | Media: {s['media']} °C | Desv. estándar: {s['desv_std']} °C")
    print("\nMedia por día:")
    for day, value in s["media_diaria"].items():
        print(f"  {day}: {value} °C")
    print(f"\nGráfica guardada en {plot(df, s['media']).resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
